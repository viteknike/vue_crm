export default {
  logout: 'Вы вышли из системы',
  'auth/user-not-found': 'Пользователя с таким Email не существует',
  'auth/wrong-password': 'Неправильный пароь',
  'auth/email-already-in-use': 'Этот Email уже используется'
}
